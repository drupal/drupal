#!/bin/sh

echo 'This is an executable script, not config.'
