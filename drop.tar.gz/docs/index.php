<H1>drop.org documentation</H1>

<H3>User guide</H3>
<LI><A HREF="mission.php">Mission statement</A></LI>
<LI><A HREF="features.php">Features</A></LI>
<LI><A HREF="todo.php">Idea's, dreamlog and todo's</A></LI>

<H3>Developers guide</H3>
<LI>Coding guidlines</LI>
<LI>Coding documentation, internel details, API</LI>

<H3>ChangeLog</H3>
<LI>A text file we simply 'include' or maybe we could slap a changelog-table and changelog-script together in PHP along with an export feature to generate a text-file?  Oh well, maybe we should start with a ChangeLog *after* the initial release?</LI>

<H3>Notes and documentation updates</H3>
<LI><U>May 13, 2000 - by Dries:</U> it's here where we will stack all documentation.  Don't get your panties in a knot because there is no cheezy 'layout': there is a 'structure' and afterall we are currently adding 'content' (read: documentation), not 'layout'.</LI>

